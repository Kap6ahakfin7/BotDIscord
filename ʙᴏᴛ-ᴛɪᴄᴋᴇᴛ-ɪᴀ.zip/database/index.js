import { JsonDatabase } from "wio.db";

const models = new JsonDatabase({ databasePath: "database/models.json"})
const emojis = new JsonDatabase({ databasePath: "database/emojis.json"})
const tickets = new JsonDatabase({ databasePath: "database/tickets.json"})
const config = new JsonDatabase({ databasePath: "database/config.json"})
const messages = new JsonDatabase({ databasePath: "database/messages.json"})

export {
    models,
    emojis,
    tickets,
    config,
    messages
}