import { SlashCommandBuilder, PermissionFlagsBits, Embed, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, PermissionsBitField } from "discord.js";
import { config } from "../../database/index.js";
import { editReplyMessage, replyMessage } from "../../functions/defaultMessages.js";

export default {
    data: new SlashCommandBuilder()
        .setName("setar")
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .setDescription('Envie o painel de ticket')
        .addSubcommand(sb => sb.setName("ticket").setDescription("Envie o painel de ticket")),

    async execute(interaction, client) {

        if (!config.get("description")) {
            return replyMessage({ interaction: interaction, type: "error", message: "Por favor, configure o painel de ticket para realizar este comando." })
        }

        await interaction.channel.permissionOverwrites.set([
            {
              id: interaction.guild.id,
              deny: [PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.CreatePublicThreads, PermissionsBitField.Flags.CreatePrivateThreads, PermissionsBitField.Flags.MentionEveryone],
              allow: [PermissionsBitField.Flags.SendMessagesInThreads]
            }
          ]);

        await interaction.deferReply({ ephemeral: true })

        const embed = new EmbedBuilder()
            .setColor(config.get("embed_color"))
            .setDescription(config.get("description"))

        if (config.get("title")) {
            embed.setTitle(config.get("title"))
        }

        if (config.get("banner")) {
            embed.setImage(config.get("banner"))
        }

        if (config.get("footer")) {
            embed.setFooter({ text: config.get("footer"), iconURL: interaction.guild.iconURL() })
        }

        if (config.get("buttonOpen")) {
            var button = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setLabel(config.get("ticketButton.label"))
                        .setCustomId("openTicket")
                )

            if (config.get("ticketButton.emoji")) {
                button.components[0].setEmoji(config.get("ticketButton.emoji"))
            }

            if (config.get("ticketButton.style")) {
                button.components[0].setStyle(ButtonStyle[`${config.get("ticketButton.style")}`])
            }
        } else {

            if (config.get("ticketMenu.categorys").length === 0) {
                return editReplyMessage({ interaction: interaction, type: "error", message: "Nenhuma categoria adicionada ao menu." })
            }

            var menu = new ActionRowBuilder()
                .addComponents(
                    new StringSelectMenuBuilder()
                        .setCustomId("ticket-menu")
                        .setPlaceholder(config.get("ticketMenu.placeholder"))
                        .addOptions(
                            config.get("ticketMenu.categorys").map(res => ({ label: res.label, emoji: res.emoji, description: res.description, value: `openTicket-${res.label}`}))
                    )
                )
        }

        await interaction.channel.send({ embeds: [embed], components: config.get("buttonOpen") ? [button] : [menu]  }).then(res => {
            editReplyMessage({ interaction: interaction, type: "success", message: "Painel enviado com sucesso." })
        }).catch(err => {
            console.log(err)
            editReplyMessage({ interaction: interaction, type: "error", message: "Ocorreu um erro ao enviar o painel de ticket." })
        })


    }

}