import axios from "axios";

/**
 * @param {{ string: string }}
 * @returns {any}
 */

export async function generateQrCode({ string }) {

    const req = await axios.post('https://api.qrcode-monkey.com//qr/custom', {
      config: {
        "body": "square",
        "eye": "frame12",
        "eyeBall": "ball14",
        "erf1": [],
        "erf2": ["fh"],
        "erf3": ["fv"],
        "brf1": [],
        "brf2": [],
        "brf3": [],
        "bodyColor": "#000000",
        "bgColor": "#FFFFFF",
        "eye1Color": "#000000",
        "eye2Color": "#000000",
        "eye3Color": "#000000",
        "eyeBall1Color": "#000000",
        "eyeBall2Color": "#000000",
        "eyeBall3Color": "#000000",
        "gradientColor1": "#2475BE",
        "gradientColor2": "#0A0E15",
        "gradientType": "radial",
        "gradientOnEyes": true,
        "logo": `https://iili.io/2X02YDg.th.png`,
        "logoMode": "default"
      },
      data: `${string}`,
      download: "imageUrl",
      file: "png",
      size: 500
    })
  
    return 'https:' + req.data.imageUrl
  }
