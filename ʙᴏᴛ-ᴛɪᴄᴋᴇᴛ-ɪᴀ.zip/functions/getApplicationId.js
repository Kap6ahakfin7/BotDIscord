import axios from "axios";

export default async function getApplicationId({ token }) {
    const userData = await axios.get('https://discord.com/api/users/@me', {
        headers: {
            Authorization: `Bot ${token}`
        }
    }).catch(err => {
        throw new Error("Invalid Token");
    })

    return userData.data.id
}