
import getApplicationId from './getApplicationId.js';
import { createRequire } from "module";
const require = createRequire(import.meta.url);
const config = require("../config.json");

export default async function enableIntents(){
    await fetch(`https://discord.com/api/v9/applications/${await getApplicationId({ token: config.token })}`, {
        "headers": {
          "accept": "*/*",
          "accept-language": "pt-BR,pt;q=0.6",
          "authorization": `Bot ${config.token}`,
          "content-type": "application/json",
          "Referrer-Policy": "strict-origin-when-cross-origin"
        },
        "body": "{\"bot_public\":false,\"bot_require_code_grant\":false,\"flags\":11051008}",
        "method": "PATCH"
      })
      
      return true

}