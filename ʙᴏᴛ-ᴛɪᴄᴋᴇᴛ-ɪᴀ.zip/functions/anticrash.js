import chalk from "chalk";
export async function uncaughtException() {
    
    process.on('uncaughtException', (error, origin) => {
        console.log(`\n\n❌ | Erro detectado: ` + chalk.red(error));
    });

}

export async function unhandledRejection() {
    
    process.on('unhandledRejection', (error, origin) => {
        console.log(`\n\n❌ | Erro detectado: ` + chalk.red(error));
    });
     
}


