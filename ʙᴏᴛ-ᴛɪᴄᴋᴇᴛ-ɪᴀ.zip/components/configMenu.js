import { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, StringSelectMenuBuilder } from "discord.js";
import { config } from "../database/index.js";

export async function backButtonConfig() {

    const button = new ActionRowBuilder()
    .addComponents(
        new ButtonBuilder()
        .setCustomId("back-config")
        .setLabel("Voltar")
        .setEmoji("<:seta:1308280648083050546>")
        .setStyle(ButtonStyle.Primary)
    )

    return button
}

export async function menuConfig() {

    const menu = new ActionRowBuilder()
    .addComponents(
        new StringSelectMenuBuilder()
        .setCustomId("menu-config")
        .setPlaceholder("Selecione uma opção...")
        .addOptions(
            { label: "Painel Ticket", emoji: "<:settings:1308282965956231169>", value: `config-ticketPanel`},
            { label: "Sistema de Abertura", emoji: "<:settings:1308282965956231169>", value: `config-openSystem`},
            { label: "Sistema de Pagamentos", emoji: "<a:wallet:1308283258148093982>", value: `config-payments`},
            { label: "Assistente Virtual", emoji: "<:bot:1308283395796897803>", value: `config-AI`},
            { label: "Horario de Atendimento", emoji: "<a:relo:1308283630241579078>", value: `config-hours`},
            { label: "Cargos de Suporte", emoji: "<:security_check:1308284007028359289>", value: `config-roles`},
            { label: "Logs", emoji: "<:settings:1308282965956231169>", value: `config-logs`},
            { label: "Mensagens", emoji: "<:prompt:1308284163274707024>", value: `config-messages`},
        )
    )

    return menu
}

export async function embedConfigMenu({ interaction }) {

    const embed = new EmbedBuilder()
    .setTitle(`${interaction.guild.name} | Configurar Ticket`)
    .setColor(config.get("embed_color"))
    .setDescription(`> Olá ${interaction.user}, Bem-Vindo(a) ao Painel de configurações do seu ticket, no menu abaixo você encontra todas as possíveis configurações.`)

    return embed
}

