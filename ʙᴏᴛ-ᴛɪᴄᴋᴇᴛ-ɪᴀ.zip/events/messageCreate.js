import { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, Events } from "discord.js";
import Groq from "groq-sdk";
import { config, messages, tickets } from "../database/index.js";
import { editTicketMessage } from "../functions/editTicketMessage.js";
import { replyMessage } from "../functions/defaultMessages.js";

const groq = new Groq({ apiKey: "MTMzNDYyNTk5NjA2MTY3MTQ2Nw.Gv6i0T.DrpMlm_Kc8G_V9km1AddObe0asaQHAe3S1f0r0" });

export default {
    name: Events.MessageCreate,
    async execute(interaction, client) {

        if (interaction.author.bot) return
        if (interaction.author.system) return
        if (!interaction.content) return

        if (tickets.get(`${interaction.channel.id}`)) {
            if (tickets.get(`${interaction.channel.id}.closed`)) return

            if (tickets.get(`${interaction.channel.id}.assumido`)) return

            const userRoles = interaction.member.roles.cache

            if (config.get("supportRoles").some(role => userRoles.has(role))) {
                const member = await client.users.fetch(tickets.get(`${interaction.channel.id}.author`))

                await tickets.set(`${interaction.channel.id}.assumido`, true)
                await tickets.set(`${interaction.channel.id}.staff`, interaction.author.id)
                await editTicketMessage({ interaction: interaction, type: "new", staff: interaction.author.id, client: client })
          

                const embed = new EmbedBuilder()
                    .setDescription("> Você assumiu este atendimento e agora é responsável por acompanhar e resolver todas as questões relacionadas a ele.")
                    .setColor(config.get("embed_color"))
                    .setTimestamp()
                    .setFooter({ text: interaction.author.username, iconURL: interaction.author.avatarURL() })

                if (config.get("title")) {
                    embed.setAuthor({ name: config.get("title"), iconURL: interaction.guild.iconURL() })
                }

                const button = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                    .setCustomId("resumirTicket")
                    .setLabel("Resumir Atendimento")
                    .setStyle(ButtonStyle.Success)
                    .setEmoji("<:send:1308282480100376606>")
                    .setDisabled(config.get("IA")? false : true)
                )

                interaction.reply({ embeds: [embed], components: [button] })
                interaction.channel.setRateLimitPerUser(0)

                const embed2 = new EmbedBuilder()
                .setDescription(messages.get("assumir").replace(/{user}/g, member).replace(/{staff}/g, interaction.author))
                .setColor(config.get("embed_color"))
                .setTimestamp()

                if (config.get("title")) {
                    embed2.setAuthor({ name: config.get("title"), iconURL: interaction.guild.iconURL() })
                }

                const redirectButton = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setStyle(ButtonStyle.Link)
                        .setLabel("Ver ticket")
                        .setEmoji("<:seta:1308280648083050546>")
                        .setURL(`https://discord.com/channels/${interaction.guild.id}/${interaction.channel.id}`)
                )

                member.send({ embeds: [embed2], components: [redirectButton]}).catch(err => {
                    return
                })

            }


            if (interaction.author.id !== tickets.get(`${interaction.channel.id}.author`)) return
            if (!config.get("IA")) return


            await tickets.push(`${interaction.channel.id}.chat`, {
                role: "user",
                content: String(interaction.content),
            })

            interaction.channel.sendTyping()

            const chat = await groq.chat.completions.create({
                messages: tickets.get(`${interaction.channel.id}.chat`),
                model: config.get("model"),
                temperature: config.get("temperature"),
                max_tokens: 1024,
            });

            if (chat.choices[0]?.message?.content.length > 2000) {
                return interaction.reply({ content: "Não foi possível enviar uma mensagem com mais de 2.000 caracteres.\n-# Essa é uma mensagem automática do sistema."})
            }

            interaction.reply({ content: `${chat.choices[0]?.message?.content}\n-# Essa é uma mensagem automática do sistema.` }).then(msg => {
                tickets.push(`${interaction.channel.id}.chat`, {
                    role: "system",
                    content: String(chat.choices[0]?.message?.content),
                })
            })



        }

    }
};
