import { ActivityType, EmbedBuilder, Events, WebhookClient } from "discord.js";
import chalk from 'chalk';

export default {
	name: Events.ClientReady,
	once: true,
	async execute(client) {
		console.log("🤖 |", chalk.green(client.user.username) + chalk.white(" está online"))
		console.log("🔨 |", chalk.white("Powered by ") + chalk.blue("Deathmatch Tático ( BETA )") + chalk.white(" | ") + chalk.yellow("https://discord.gg/H46uhnUV"))

	
		
		const customActivities = [
			{ name: "🎫 Gerenciando Tickets", type: ActivityType.Custom },
			{ name: "👀 Atendendo Tickets", type: ActivityType.Custom },
			{ name: "🤖 Atendimento Automático", type: ActivityType.Custom },
		  ];
	  
		  const updateActivity = () => {
			const randomActivity =
			  customActivities[Math.floor(Math.random() * customActivities.length)];
			client.user.setPresence({
			  activities: [randomActivity],
			  status: "online",
			});
		  };
	  
		  updateActivity();
	  
		  setInterval(() => {
			updateActivity();
		  }, 5000);
	}
};
