import fs from 'fs';
import path from 'path';
import { Client, Collection, GatewayIntentBits } from 'discord.js';
import { unhandledRejection, uncaughtException } from './functions/anticrash.js';
import enableIntents from './functions/autoEnableIntents.js';
import { createRequire } from "module";
import axios from 'axios'; // Certifique-se de importar o axios
const require = createRequire(import.meta.url);
const config = require("./config.json");

uncaughtException();
unhandledRejection();

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildVoiceStates
    ],
});

console.clear();

client.commands = new Collection();

const handlersPath = path.resolve('./handlers');
const eventsPath = path.resolve('./events');
const commandsPath = path.resolve('./commands');

// Função para atualizar a descrição do bot
async function updateDescription() {
    const description = "**`🔗` Deathmatch Tático ( BETA ) ©2025\n`⚡` Sistemas únicos e personalizados\n`🔗` https://discord.gg/H46uhnUV**";

    try {
        // Atualiza a descrição do bot
        await axios.patch(`https://discord.gg/H46uhnUV${client.user.id}`, {
            description: description
        }, {
            headers: {
                "Authorization": `Bot ${config.token}`,
                "Content-Type": 'application/json',
            }
        });
        console.log("Descrição atualizada com sucesso!");
    } catch (error) {
        console.error("Erro ao atualizar a descrição do bot:", error);
    }
}

// Função para carregar os handlers
const loadHandlers = async () => {
    const handlers = fs.readdirSync(handlersPath).filter(file => file.endsWith('.js'));
    await Promise.all(handlers.map(async file => {
        const filePath = new URL(`file://${path.resolve(handlersPath, file)}`).href;
        const { default: handler } = await import(filePath);
        await handler(client);
    }));
};

// Função para carregar os eventos
const loadEvents = async () => {
    const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));
    await client.handleEvents(eventFiles, eventsPath);
};

// Função para carregar os comandos
const loadCommands = async () => {
    const commandFolders = fs.readdirSync(commandsPath);
    await client.handleCommands(commandFolders, commandsPath);
};

// Função principal de inicialização do bot
(async () => {
    await enableIntents();
    await loadHandlers();
    await loadEvents();
    await loadCommands();

    client.login(config.token);

    // Garantir que o bot só atualize a descrição após estar completamente logado e pronto
    client.once('ready', () => {
        // Atualiza a descrição do bot imediatamente quando ele estiver pronto
        updateDescription();

        // Atualiza a descrição a cada 10 minutos (600.000 milissegundos)
        setInterval(updateDescription, 10800000); // 10.800.000 ms = 3 horas
    });
})();
