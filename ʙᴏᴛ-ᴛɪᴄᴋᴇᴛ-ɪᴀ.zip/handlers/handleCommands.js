import fs from "fs";
import { REST, Routes } from 'discord.js';
import chalk from 'chalk';
import getApplicationId from "../functions/getApplicationId.js";
import { createRequire } from "module";
const require = createRequire(import.meta.url);
const config = require("../config.json");

export default (client) => {
	const clientId = getApplicationId({ token: config.token })

	client.handleCommands = async (commandFolders, path) => {

		client.commandArray = [];

		for (const folder of commandFolders) {
			const commandFiles = fs
				.readdirSync(`${path}/${folder}`)
				.filter((file) => file.endsWith('.js'));
			for (const file of commandFiles) {
				const command = await import(`../commands/${folder}/${file}`);

				client.commands.set(command.default.data.name, command.default);
				client.commandArray.push(command.default.data.toJSON());
			}
		}

		const rest = new REST().setToken(config.token);

		(async () => {
			try {

				await rest.put(Routes.applicationCommands(await clientId), {
					body: client.commandArray,
				});

				console.log("🔧 |", chalk.green(client.commandArray.length) + chalk.white(" comando(s) carregado(s)"))

			} catch (error) {
				return
			}
		})();
	};
};