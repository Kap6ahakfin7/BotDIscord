
import path from "path";
export default async (client) => {
    client.handleEvents = async (eventFiles, eventsPath) => {
        const loadEvent = async (file) => {
            const eventPath = new URL(`file://${path.resolve(eventsPath, file)}`).href;
            const { default: event } = await import(eventPath);
            if (!event || !event.name || !event.execute) {
                console.error(`O arquivo ${file} não exporta um evento válido.`);
                return;
            }
            if (event.once) {
                client.once(event.name, (...args) => event.execute(...args, client));
            } else {
                client.on(event.name, (...args) => event.execute(...args, client));
            }
        };

        await Promise.all(eventFiles.map(loadEvent));
    };
};
